# nssdb puppet module

very simple puppet module to create an NSS database and add a certificate
and key via PEM files.
