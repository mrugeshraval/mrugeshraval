require 'puppet_x/keystone/type/default_domain'
require 'puppet_x/keystone/type/required'
require 'puppet_x/keystone/type/read_only'
